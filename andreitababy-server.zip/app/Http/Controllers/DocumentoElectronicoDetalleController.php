<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DocumentoElectronicoDetalleController extends Controller
{
    //
}
