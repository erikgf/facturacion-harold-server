<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CotizacionDetalleController extends Controller
{
    //
}
