<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SucursalMovimientoController extends Controller
{
    //
}
