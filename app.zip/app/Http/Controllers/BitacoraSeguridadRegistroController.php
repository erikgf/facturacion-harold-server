<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BitacoraSeguridadRegistroController extends Controller
{
    //
}
