<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VentaDetalleController extends Controller
{
    //
}
